import DataTable from "../../components/data/DataTable"
import styles from "../dashboard/Dashboard.module.scss"
import { useState, useEffect, useCallback } from "react";
import FormCard from "../../components/formcard/FormCard";
import FilterHeaderDataContainer from "../../components/leftHeaderNavigation/filterHeaderDataContainer";
import ToolsHeader from "../../components/toolsheader/ToolsHeader";
export default function Dashboard() {
    const coloumns = [
        { key: 'id', header: 'ID' },
        { key: 'name', header: 'Name' },
        { key: 'email', header: 'Email' },
        { key: 'department', header: 'Department' },
        { key: 'age', header: 'Age' },
    ];
    const [dataLoaded, setDataLoaded] = useState([]);
    
    useEffect(() => {
        import("../../data.json")
            .then((res) => {
                setDataLoaded(res.default);
            })
            .catch((err) => console.error("Error loading JSON:", err));
    }, []);

    function handleSubmit() {

    }
    const onHandleChangeDepartment = useCallback(async (department)=>{
        const res =  await import("../../data.json")
        const data =  res.default;
        setDataLoaded(data.filter((v)=>v.department.toLowerCase().includes(department.toLowerCase())));
            // .then((res) => {
            //     const data = res.default;
            //     setDataLoaded(data.filter((v)=>v.department.toLowerCase().includes(department.toLowerCase())));
            // })
            // .catch((err) => console.error("Error loading JSON:", err));
    },[]);


    function onCheckBoxChange(label){
        console.log(label);
    }

    const filterByName = useCallback((name)=>{
        import("../../data.json")
        // console.log(name)
        .then((res)=>{
            const data = res.default;
            setDataLoaded(data.filter((value)=>value.name.toLowerCase().includes(name.toLowerCase())));
        })
            .catch((err) => console.error("Error loading JSON:", err));       
    },[]);

    return (
        <>
            <div className={styles.dashboardpage} >
                <div className={styles.dashboardContainerLeft} >
                    <FilterHeaderDataContainer  onHandleChange = {onHandleChangeDepartment} onSearchByName = {filterByName} />
                    <DataTable columns={coloumns} data={dataLoaded}  isCheckbox={true} onCheckBoxChange={onCheckBoxChange}/>
                </div>
                <div className={styles.dashboardContainerRight} >
                    <ToolsHeader />
                    <div className={styles.updateForm} >
                        <FormCard formType="addEmployee" onSubmit={handleSubmit} />
                    </div>
                </div>
            </div>
        </>
    )
}