import styles from "../signup/Signup.module.scss"
import { Link } from "react-router-dom"
export default function Signup() {
    return (
        <>
            <div className={styles.signupPage}>
                <div className={styles.signupContainer}>
                    <h2>Create Account</h2>


                    <form>
                        <input type="text" placeholder="Full Name" />
                        <input type="email" placeholder="Email" />
                        <input type="password" placeholder="Password" />
                        <button type="submit">Sign Up</button>
                    </form>


                    <p className="loginText">
                        Already have an account?  <Link to="/login"> Login</Link>
                    </p>
                </div>
            </div>
        </>
    )
}