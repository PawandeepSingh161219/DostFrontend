import styles from "../login/Login.module.scss"
import { useEffect } from "react"
import { useNavigate } from "react-router-dom";
import useContextData from "../../hooks/useContext";
import { setDataInfo } from "../../utils/storage";

export default function Login() {
  const {setIsLogin,toast,setLoaderInfo} = useContextData();
  const navigate = useNavigate();
  function handleSubmit(event){
    event.preventDefault();
    setDataInfo({login:true})
    toast("Login Successfully")
    setTimeout(()=>{
       setIsLogin(true);
       navigate('/dashboard')
    },3000)
    
  }
  useEffect(()=>{
 
  },[])
  return (
    <div className={styles.loginPage}>
      <div className={styles.loginBox}>
        <h2>Login</h2>
     
        <form onSubmit={handleSubmit}>
          <div className={styles.inputGroup}>
            <label>Email</label>
            <input type="email" placeholder="Enter your email" />
          </div>

          <div className={styles.inputGroup}>
            <label>Password</label>
            <input type="password" placeholder="Enter your password" />
          </div>
          <div className={styles.buttonContainer}  >
            <button className={styles.button} type="submit">Login</button>
          </div>
        </form>
      </div>
    </div>

  )
}