import styles from "./Home.module.scss";

 export default function Home() {
  return (
    <div className={styles.home}>

      {/* HERO SECTION */}
      <section className={styles.heroSection}>
        <h1>Build Your Skills with Confidence</h1>
        <p>
          Learn modern web development, enhance your coding skills, and grow 
          your career with structured guidance.
        </p>
        <button className={styles.heroBtn}>Explore Courses</button>
      </section>

      {/* CONTENT SECTION */}
      <section className={styles.contentSection}>
        <div className={styles.card}>
          <h3>Frontend Development</h3>
          <p>
            Master HTML, CSS, JavaScript, React, and UI frameworks with 
            real-world projects and expert guidance.
          </p>
        </div>

        <div className={styles.card}>
          <h3>Backend Development</h3>
          <p>
            Learn Node.js, Express, MongoDB, and API development to build 
            scalable server-side applications.
          </p>
        </div>

        <div className={styles.card}>
          <h3>UI/UX Design</h3>
          <p>
            Explore design fundamentals, wireframing, prototyping, and 
            creating aesthetic user interfaces.
          </p>
        </div>
      </section>
    </div>
  );
}


