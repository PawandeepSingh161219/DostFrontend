
import './App.css'
import GlobalUiContext from './context/GlobalUiContext'

import AppRouter from './route/AppRouter'

function App() {
  //console.log(import.meta.env.VITE_API_URL)
  return (
    <>
      <GlobalUiContext>
        <AppRouter />
      </GlobalUiContext>
    </>
  )
}

export default App
