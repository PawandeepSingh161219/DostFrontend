import { BrowserRouter, Route, Routes, } from 'react-router-dom'
import Login from '../pages/login/Login'
import Signup from '../pages/signup/Signup'
import Dashboard from '../pages/dashboard/Dashboard'
import Home from '../pages/home/Home'
import NotFound from '../pages/notfound/404'
import MainLayout from '../components/mainlayout/MainLayout'
import PrivateLayout from '../components/mainlayout/PrivateLayout'
import useContextData from '../hooks/useContext'

function AppRouter() {
    const { isLogin } = useContextData();
    return (
        <>
            <BrowserRouter>
                <Routes>
                    {
                        isLogin ?
                            <Route path='' element={<PrivateLayout />}>
                                <Route path='dashboard' element={<Dashboard />}></Route>
                            </Route>
                            :
                            <Route path='' element={<MainLayout />}>
                                <Route index element={<Home />}></Route>
                                <Route path='login' element={<Login />}></Route>
                                <Route path='signup' element={<Signup />}></Route>
                            </Route>
                    }
                    <Route path='*' element={<NotFound />}></Route>

                </Routes>
            </BrowserRouter>

        </>
    )
}

export default AppRouter
