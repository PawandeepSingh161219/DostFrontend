import axios from "axios";

//console.log("API URL:", import.meta.env.VITE_API_URL);

const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL, // Meta environment URL
  timeout: 10000,
});

// OPTIONAL interceptors
api.interceptors.request.use(
  (config) => {
    // Example token
    // const token = localStorage.getItem("token");
    // if (token) config.headers.Authorization = `Bearer ${token}`;
    return config;
  },
  (error) => Promise.reject(error)
);

export default api;
