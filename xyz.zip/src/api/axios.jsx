import axios from "axios";

let axiosInstance = null;

export const getAxiosInstance = () => {
  if (axiosInstance) return axiosInstance;

  axiosInstance = axios.create({
    baseURL: process.env.API_BASE_URL || "http://localhost:5000/api",
    timeout: 10000,
    headers: {
      "Content-Type": "application/json",
    },
  });

  // Request Interceptor
  axiosInstance.interceptors.request.use(
    (config) => {
      const token = localStorage.getItem("token");
      if (token && config.headers) {
        config.headers.Authorization = `Bearer ${token}`;
      }
      return config;
    },
    (error) => Promise.reject(error)
  );

  // Response Interceptor
  axiosInstance.interceptors.response.use(
    (response) => response,
    (error) => {
      if (error.response?.status === 401) {
        console.log("Unauthorized. Please login again.");
      }
      return Promise.reject(error);
    }
  );

  return axiosInstance;
};