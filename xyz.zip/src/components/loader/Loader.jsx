import { ToastContainer} from 'react-toastify';
export default function Loader(){
    return( 
            <>
                <ToastContainer position="top-right" />
            </>
    )
}