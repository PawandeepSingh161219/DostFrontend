import NavigationBar from "../nav/NavigationBar";
import SearchSection from "../searchsection/SearchSection";
import styles from "../header/Header.module.scss"
import { Link, useNavigate } from "react-router-dom"
import { IMAGES } from "../../assets/images";
import useContextData from "../../hooks/useContext";
import { setDataInfo } from "../../utils/storage";
const public_images = import.meta.env.VITE_PUBLIC_IMAGES;


export default function Header() {
    const navigate = useNavigate();
    const { setIsLogin, toast, isLogin } = useContextData();
    return (



        <header>
            {/* <p>header</p>
            <nav>
                <ul>
                    <li><Link to="login">Login</Link>   </li>
                </ul>
            </nav> */}
            <div className={styles.outerdiv}>
                <div className={styles.centerdiv} >
                    <div className={styles.websitelogo} >
                        {/* <img src={IMAGES.logoPhoto} /> */}
                        <img src={`${public_images}logoKaPhoto.png`} />
                    </div>
                    <div className={styles.nav} >
                        <nav>
                            <ul>
                                <li><Link to="/">Home</Link></li>
                                {
                                    !isLogin ? (
                                        <>
                                            <li><Link to="login">Login</Link></li>
                                            <li><Link to="signup">Signup</Link> </li>
                                        </>
                                    )
                                    :
                                    <>
                                <li><a href="#" onClick={() => {
                                    setIsLogin(false);
                                    setDataInfo({login:false})
                                    navigate('/login');
                                    toast('Logout Successfully')
                                }}>Logout</a></li>
                                <li><Link to="dashboard">Dashboard</Link></li>
                                </>
                                }



                               

                            </ul>
                        </nav>
                    </div>
                </div>
            </div>

        </header>
    )
}