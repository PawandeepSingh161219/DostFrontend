import { memo } from "react"
import styles from "../leftHeaderNavigation/filterHeaderDataContainer.module.scss"
import { CiSearch, CiEraser } from "react-icons/ci"

function FilterHeaderDataContainer({onHandleChange=()=>console.log("click") , onSearchByName=()=>console.log("doubleClick")}) {

    return (
        <div className={styles.filterHeaderDataContainer} >
            <div className={styles.searchIcon} >
                <CiSearch style={{ color: "blue", fontSize: "30px" }} />
            </div>
            <div className={styles.searchByName} >
                <input type="search" placeholder="Search by name..." onChange={(e)=>onSearchByName(e.target.value)}/>
            </div>
            <div className={styles.searchByDepartment} >
                <select id="helloji"  onChange={(e)=>onHandleChange(e.target.value)}>
                    <option value="">Choose Department</option>
                    <option value="Marketing">Marketing</option>
                    <option value="Hr">Hr</option>
                    <option value="Finance">Finance</option>
                    <option value="Sales">Sales</option>
                    <option value="Support">Support</option>
                    <option value="Engineering">Engineering</option>
                </select>

            </div>
            <div className={styles.editData} >
                <CiEraser style={{ color: "blue", fontSize: "30px" }} />
            </div>
        </div>
    )
};

export default memo(FilterHeaderDataContainer);