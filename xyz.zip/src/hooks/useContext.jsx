import { useContext } from "react";
import { UiData } from "../context/UiData";

export default function useContextData(){
    return useContext(UiData);
}