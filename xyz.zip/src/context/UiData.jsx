import { createContext } from "react";

 export const UiData=createContext(null);