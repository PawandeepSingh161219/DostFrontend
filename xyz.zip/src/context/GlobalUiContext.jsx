import { useEffect, useState } from "react";
import { UiData } from "./UiData";
import Loader from "../components/loader/Loader";
import { toast } from "react-toastify";
import 'react-toastify/dist/ReactToastify.css';
import { getDataInfo } from "../utils/storage";
export default function GlobalUiContext({ children }) 
{
    const [isLogin, setIsLogin] = useState(false);
    const [loader, setLoader] = useState(false)
    function setLoaderInfo(isLoad) {
        console.log(isLoad)
        setLoader(isLoad);
    }
    const initData = {
        isLogin,
        setIsLogin,
        setLoaderInfo,
        toast
    }

    useEffect(()=>{
        const sData = getDataInfo();
        if(sData?.login){
            setIsLogin(true);
        }
    },[])
    return (
        <>
            <UiData.Provider value={initData}>
                <Loader isLoader={loader} />
                {children}
            </UiData.Provider>
        </>
    )
}